//
//  ChatConversation+CoreDataClass.m
//  XmppProject
//
//  Created by IntelcentMac on 17/7/17.
//  Copyright © 2017年 wh_shine. All rights reserved.
//

#import "ChatConversation+CoreDataClass.h"

@implementation ChatConversation

@end
