//
//  ChatConversation+CoreDataClass.h
//  XmppProject
//
//  Created by IntelcentMac on 17/7/17.
//  Copyright © 2017年 wh_shine. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface ChatConversation : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "ChatConversation+CoreDataProperties.h"
