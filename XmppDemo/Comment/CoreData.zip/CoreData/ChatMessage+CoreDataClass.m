//
//  ChatMessage+CoreDataClass.m
//  XmppProject
//
//  Created by IntelcentMac on 17/7/17.
//  Copyright © 2017年 wh_shine. All rights reserved.
//

#import "ChatMessage+CoreDataClass.h"

@implementation ChatMessage

-(void)updateWithMessageModel:(MessageModel *)model{
    if ([model isKindOfClass:[MessageModel class]]) {
        NSString *contactId = @"";
        if (model.from.phone isEqualToString:) {
            
        }
        if (model.typeChat == IMChatTypeSingle) {
            self.conversationId = model
        }
        self.conversationId
    }
    
}

@end
